/*
  LiquidCrystal Library - Hello World

 Demonstrates the use a 16x2 LCD display.  The LiquidCrystal
 library works with all LCD displays that are compatible with the
 Hitachi HD44780 driver. There are many of them out there, and you
 can usually tell them by the 16-pin interface.

 This sketch prints "Hello World!" to the LCD
 and shows the time.

 The circuit:
 * LCD RS pin to PA1 (digital pin 0)
 * LCD Enable pin to PA2 (digital pin 1)
 * LCD D4 pin to PA3 (digital pin 2)
 * LCD D5 pin to PD2 (digital pin 11)
 * LCD D6 pin to PD3 (digital pin 12)
 * LCD D7 pin to PD4 (digital pin 13)
 * LCD R/W pin to ground
 * LCD VSS pin to ground
 * LCD VCC pin to 5V
 * 10K potentiometer:
 * ends to +5V and ground
 * wiper to LCD VO pin (pin 3)

 Library originally added 18 Apr 2008
 by David A. Mellis
 library modified 5 Jul 2009
 by Limor Fried (http://www.ladyada.net)
 example added 9 Jul 2009
 by Tom Igoe
 modified 22 Nov 2010
 by Tom Igoe
 modified 23 Jan 2017
 by Michael Mayer

 This example code is in the public domain.

 http://www.arduino.cc/en/Tutorial/LiquidCrystal
 */

// include the library code:
#include <LiquidCrystal.h>

// initialize the library with the numbers of the interface pins
// Pines RS, E, D4, D5, D6, D7 (el STM8S103 tiene PA3; los de 32 patas no)
#if defined(ARDUINO_STM8S_BLUE) || defined(ARDUINO_STM8S003F3)
LiquidCrystal (lcd,PA1,PA2, PA3,PD2,PD3,PD4);
#elif defined(ARDUINO_STM8S_UNO) || defined(ARDUINO_STM8S_MB)
LiquidCrystal (lcd,12,11, 5,4,3,2);       // como en Arduino UNO
#else
LiquidCrystal (lcd,PA1,PA2, PD7,PD2,PD3,PD4);
#endif

void setup() {
  // set up the LCD's number of columns and rows:
  lcd_begin(16, 2);
  // Print a message to the LCD.
  lcd_print_s("hello, world!");
}


void loop() {
  // set the cursor to column 0, line 1
  // (note: line 1 is the second row, since counting begins with 0):
  lcd_setCursor(0, 1);
  // print the number of seconds since reset:
  lcd_print_u(millis() / 1000);
}
